// to solve ReferenceError: regeneratorRuntime is not defined
import 'babel-polyfill'

describe('Client Test', () => {
    // TODO: add your test cases to test client
})
