// TODO: import the url check function

describe('Test check url functionality', () => {
    test('Testing the checkUrl function defined or not', () => {
        // TODO: write your logic here
    })

    test('Testing the checkUrl function return false for invalid url', () => {
        // TODO: write your logic here
    })

    test('Testing the checkUrl function return true for valid url', () => {
        // TODO: write your logic here
    })
})
